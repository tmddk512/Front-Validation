package bitedu.bipa.dao;

import bitedu.bipa.utils.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberDAO {
    private ConnectionManager manager;

    public MemberDAO() {
        this.manager = ConnectionManager.getInstance();
    }

    public int checkUserId(String userId) {
        int result = 0;
        String sql = "select count(user_id) as count \n" +
            "from book_user\n" +
            "where user_id = ?;";
        Connection con = manager.getConnection();
        try {
            con.setAutoCommit(false);
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                result = rs.getInt("count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}
