package bitedu.bipa.service;

import bitedu.bipa.dao.MemberDAO;

public class MemberService {
    private MemberDAO dao;

    public MemberService() {
        this.dao = new MemberDAO();
    }

    public int checkUserId(String userId) {
        return dao.checkUserId(userId);
    }
}
