package bitedu.bipa.controller;

import bitedu.bipa.utils.ConnectionManager;

public class Main {
    public static void main(String[] args) {
//        ConnectionManager.getInstance().getConnection();
    }
}
